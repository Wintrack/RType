var namespaceplayer =
[
    [ "CPlayer", "classplayer_1_1_c_player.html", "classplayer_1_1_c_player" ]
];
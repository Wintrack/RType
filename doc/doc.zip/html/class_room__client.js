var class_room__client =
[
    [ "Room_client", "class_room__client.html#a4ab437a5f61af348443114a82fbcd7a0", null ],
    [ "~Room_client", "class_room__client.html#a0f906868f5ff8db92adc753931b8bd6e", null ],
    [ "Room_read_from_server", "class_room__client.html#aba787a94c943656df493d0745014dda1", null ],
    [ "Renders", "class_room__client.html#ad0e65675a1db9e15016bdec10096f3ea", null ]
];
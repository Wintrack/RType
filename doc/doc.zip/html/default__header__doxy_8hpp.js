var default__header__doxy_8hpp =
[
    [ "player::CPlayer", "classplayer_1_1_c_player.html", "classplayer_1_1_c_player" ]
];
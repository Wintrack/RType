var _macro_8hpp =
[
    [ "s_Client", "structs___client.html", null ],
    [ "INSTRUCTION_CREATE_ROOM_Client", "struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html", null ],
    [ "INSTRUCTION_JOIN_LOBBY_Serv", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html", null ],
    [ "INSTRUCTION_JOIN_ROOM_Client", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html", null ],
    [ "INSTRUCTION_GENERIC", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html", null ],
    [ "INSTRUCTION_Serv_to_Client_room", "struct_i_n_s_t_r_u_c_t_i_o_n___serv__to___client__room.html", null ],
    [ "INSTRUCTION_Client_in_room", "struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html", null ]
];
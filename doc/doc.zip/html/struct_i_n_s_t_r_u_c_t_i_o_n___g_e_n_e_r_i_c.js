var struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c =
[
    [ "info_player", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#aac28d43b16ef9f72925fd9dc5d45a041", null ],
    [ "instruction", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#ad2a960a1c4ce9419f1ce5bfa4d760c68", null ],
    [ "maxpl", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#a8b82a06a1d6353f5bfcf214fc1cabe89", null ],
    [ "name_room_created", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#a2e86670769993895825734374c15ce6e", null ],
    [ "name_selected", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#ada77bd1e8d1d660cd231d1393c9be33f", null ],
    [ "RAM_DATABASE", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#adbd384c18d28cb9f622fffcb7473522b", null ],
    [ "rooms_in_lobby", "struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#a39443826b0ebfa248d1ea299a2b0b94d", null ]
];
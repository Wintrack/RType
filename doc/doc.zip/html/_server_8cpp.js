var _server_8cpp =
[
    [ "get_lobby_maxpl", "_server_8cpp.html#a8347f1d57f7c9be9672c8a5e0d4dac95", null ],
    [ "get_lobby_names", "_server_8cpp.html#a859d67d9fcc408b92609b724e50248ab", null ]
];
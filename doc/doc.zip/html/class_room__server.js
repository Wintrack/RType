var class_room__server =
[
    [ "Room_server", "class_room__server.html#aa48d886f70c6dc84e22f851bc46cd445", null ],
    [ "~Room_server", "class_room__server.html#aaf011bb8a63e64e4c22d4640bd3a3580", null ],
    [ "Add_client", "class_room__server.html#ab1e1f2fbfa296ad3ed7ece5ae653716f", null ],
    [ "Create_room", "class_room__server.html#a28ed6536596128f8ad4177187025906c", null ],
    [ "Treating_Game_Loop", "class_room__server.html#a115dc7952e5484fc1094135fd71485aa", null ]
];
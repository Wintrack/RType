var class_menu =
[
    [ "Menu", "class_menu.html#ad466dd83355124a6ed958430450bfe94", null ],
    [ "~Menu", "class_menu.html#a831387f51358cfb88cd018e1777bc980", null ],
    [ "Display", "class_menu.html#a748c59d87907f1a33285a8ecb89ee261", null ]
];
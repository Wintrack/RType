var classser =
[
    [ "ser", "classser.html#a5820ab28918844d21b5f86424b9df5b0", null ],
    [ "~ser", "classser.html#a76eea561f573043734670c2949fd23f4", null ],
    [ "deserialize", "classser.html#a656e3cc2e2d58ac35ddfce1915fde885", null ],
    [ "serialize", "classser.html#a44d67fc6da91940c3061dbf916cfaf7e", null ]
];
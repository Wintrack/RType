var class_client_internal_logic =
[
    [ "ClientInternalLogic", "class_client_internal_logic.html#a1d6198a745bd2e5cc1816213019ea13e", null ],
    [ "~ClientInternalLogic", "class_client_internal_logic.html#ad1ca150f316dcf462de65439d688916b", null ],
    [ "Client_Display", "class_client_internal_logic.html#a49c0d9cd61762d3b2b151cde1779ea14", null ],
    [ "getInfos", "class_client_internal_logic.html#a7f3acd6cf2ef53ba25a9cd3f7f740b00", null ],
    [ "Verify_Cache", "class_client_internal_logic.html#a67d8028cf60c1e84b05ee776b6018868", null ]
];
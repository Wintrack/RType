var struct_str__t =
[
    [ "len", "struct_str__t.html#a8ffa500232897558c615a93437b11e20", null ],
    [ "sz", "struct_str__t.html#ab94674acae4352eea6a92d6416dba8a6", null ]
];
var serialize_8hpp =
[
    [ "ser", "classser.html", "classser" ]
];
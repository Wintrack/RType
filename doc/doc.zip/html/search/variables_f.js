var searchData=
[
  ['ram_5fdatabase_0',['RAM_DATABASE',['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#adbd384c18d28cb9f622fffcb7473522b',1,'INSTRUCTION_GENERIC']]],
  ['real_5finfos_1',['real_infos',['../class_client.html#a3eafac69ba5f531a5f6d1626ed22d69e',1,'Client']]],
  ['receive_5fbuffer_2',['receive_buffer',['../class_client.html#a7492c72d1fa7acf49b27f1700be5ff3e',1,'Client::receive_buffer()'],['../class_server.html#a62c2efdbbd4301b286d3a64d1ccb8322',1,'Server::receive_buffer()']]],
  ['renders_3',['Renders',['../class_room__client.html#ad0e65675a1db9e15016bdec10096f3ea',1,'Room_client']]],
  ['rendersys_4',['RenderSys',['../class_client_internal_logic.html#a664f40ecac32be207c89cb999e867329',1,'ClientInternalLogic']]],
  ['room_5fig_5',['Room_ig',['../class_client.html#a184fea48f9116d5bf7a149cea149e344',1,'Client']]],
  ['room_5fname_6',['room_name',['../class_room__server.html#a77b7c8d24acf2071ac6e2b35f995b49b',1,'Room_server']]],
  ['rooms_5fin_5flobby_7',['rooms_in_lobby',['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html#af3ad6ac50f2cf3f0c9917903f06daa34',1,'INSTRUCTION_JOIN_LOBBY_Serv::rooms_in_lobby()'],['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#a39443826b0ebfa248d1ea299a2b0b94d',1,'INSTRUCTION_GENERIC::rooms_in_lobby()']]],
  ['rooms_5fon_5flist_8',['rooms_on_list',['../class_lobby___serv.html#ab61482e9274be7f2383bbbad8aec7959',1,'Lobby_Serv']]]
];

var searchData=
[
  ['nb_5fstr_5ferr_0',['NB_STR_ERR',['../default__doxy_8cpp.html#a453c49b2528434b9260435d9098c6114a8aff2f6d0b0a343fc66bbb89d2128ad9',1,'default_doxy.cpp']]]
];

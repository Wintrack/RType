var searchData=
[
  ['max_5fplayers_0',['max_players',['../class_room__server.html#abb23537d96c4170c026f09e9a4262cef',1,'Room_server']]],
  ['maxpl_1',['maxpl',['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html#aaccc2590738cc2e59411065062211e03',1,'INSTRUCTION_JOIN_LOBBY_Serv::maxpl()'],['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#a8b82a06a1d6353f5bfcf214fc1cabe89',1,'INSTRUCTION_GENERIC::maxpl()']]],
  ['maxplay_2',['maxplay',['../struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html#a6bd8b4c1fdb3d79daf8fecc4f9189333',1,'INSTRUCTION_CREATE_ROOM_Client']]],
  ['menu_5fclient_3',['Menu_client',['../class_client.html#a44cc95cd08c063bea0202b72d6c1829a',1,'Client']]]
];

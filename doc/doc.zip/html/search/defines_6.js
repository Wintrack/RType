var searchData=
[
  ['var_5fdelimiter_0',['VAR_DELIMITER',['../_macro_8hpp.html#a16b4df4c531edc0aeb75f7776ccc2e18',1,'Macro.hpp']]]
];

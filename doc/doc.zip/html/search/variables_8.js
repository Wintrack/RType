var searchData=
[
  ['id_0',['id',['../class_client_internal_logic.html#a2e2a795f2ae527a59cf3157a93931054',1,'ClientInternalLogic::id()'],['../struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#aa667c68974ce686250e508d330f39844',1,'INSTRUCTION_Client_in_room::id()'],['../struct_entity__to__display.html#a16111787afac59ff6aec9c5972638a46',1,'Entity_to_display::id()']]],
  ['id_5fgenerator_1',['id_generator',['../class_server_internal_logic.html#a8770aa70374837ef65ef0d29bd9651b5',1,'ServerInternalLogic']]],
  ['info_5fplayer_2',['info_player',['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#aac28d43b16ef9f72925fd9dc5d45a041',1,'INSTRUCTION_GENERIC']]],
  ['instruction_3',['instruction',['../struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html#af34e093ea3d85779a19054c45d5828e9',1,'INSTRUCTION_CREATE_ROOM_Client::instruction()'],['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html#a4a2f76ccdb75f6f55545063e6b39b433',1,'INSTRUCTION_JOIN_LOBBY_Serv::instruction()'],['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html#af7761952e4f132e7fa1e7b4af21e5771',1,'INSTRUCTION_JOIN_ROOM_Client::instruction()'],['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#ad2a960a1c4ce9419f1ce5bfa4d760c68',1,'INSTRUCTION_GENERIC::instruction()']]],
  ['io_5fcontext_4',['io_context',['../class_client.html#a4488b6e3f445483469de902e46cdc383',1,'Client']]],
  ['ip_5',['IP',['../structs___client.html#acaceb5c02181796f8119f32ace8af514',1,'s_Client']]]
];

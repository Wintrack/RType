var searchData=
[
  ['systems_0',['Systems',['../namespace_systems.html',1,'']]]
];

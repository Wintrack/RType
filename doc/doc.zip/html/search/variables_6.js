var searchData=
[
  ['frameheightexit_0',['frameHeightExit',['../class_lobby___client.html#ac34da801e1bc2776ea0c58ad1a51ac9e',1,'Lobby_Client::frameHeightExit()'],['../class_menu.html#ac574152afa5a620be2f98fc7d2180205',1,'Menu::frameHeightExit()']]],
  ['frameheightnewgame_1',['frameHeightNewgame',['../class_lobby___client.html#a3218a6a80952a06075b31e876bc3c1e4',1,'Lobby_Client::frameHeightNewgame()'],['../class_menu.html#a122fefd85280e5dbfa11ed06f1c5b2e4',1,'Menu::frameHeightNewgame()']]],
  ['frameheightoption_2',['frameHeightOption',['../class_menu.html#a3eed2f3bed530f24151075249ed9da86',1,'Menu']]]
];

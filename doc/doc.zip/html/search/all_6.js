var searchData=
[
  ['healthsystem_0',['HealthSystem',['../class_systems_1_1_health_system.html',1,'Systems']]]
];

var searchData=
[
  ['database_0',['DATABASE',['../class_client_internal_logic.html#abd3881fa5ce1a13d0e2b4f6c55336c46',1,'ClientInternalLogic::DATABASE()'],['../class_server_internal_logic.html#a3c011b58505b53ced0a035b1d47ea3a5',1,'ServerInternalLogic::DATABASE()']]],
  ['deser_5fbuffer_1',['deser_buffer',['../classser.html#ac9172f187dfceca4addb1e7c20561df2',1,'ser']]],
  ['display_5fon_5fscreen_2',['Display_on_screen',['../class_client_internal_logic.html#a3754296de6e54406e826127324569242',1,'ClientInternalLogic']]]
];

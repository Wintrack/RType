var searchData=
[
  ['champ_5fdelimiter_0',['CHAMP_DELIMITER',['../_macro_8hpp.html#a4141baf6a221a99f27bb7f4b879def20',1,'Macro.hpp']]],
  ['client_5fhpp_5f_1',['CLIENT_HPP_',['../_client_8hpp.html#aebb241247976e8c047608296cb5108b3',1,'Client.hpp']]],
  ['create_5froom_5fins_2',['CREATE_ROOM_INS',['../_macro_8hpp.html#a9a4caf7d1328b692c5ddb1b998a92be3',1,'Macro.hpp']]]
];

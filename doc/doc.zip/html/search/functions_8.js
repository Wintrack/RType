var searchData=
[
  ['receive_5ffrom_5fclient_0',['Receive_from_client',['../class_server_internal_logic.html#ac818fb618348e26b07abcfe756353198',1,'ServerInternalLogic']]],
  ['room_5fserver_1',['Room_server',['../class_room__server.html#aa48d886f70c6dc84e22f851bc46cd445',1,'Room_server']]]
];

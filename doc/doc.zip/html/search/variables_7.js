var searchData=
[
  ['game_0',['Game',['../class_room__server.html#a74d6115fd1fce2b8e4fd503e3da31287',1,'Room_server']]]
];

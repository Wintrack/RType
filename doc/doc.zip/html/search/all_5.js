var searchData=
[
  ['get_5fendpoint_0',['get_endpoint',['../class_server.html#a5390eb0c3cf74e783533cdd3ae14e3f3',1,'Server']]],
  ['getinfos_1',['getInfos',['../class_client_internal_logic.html#a7f3acd6cf2ef53ba25a9cd3f7f740b00',1,'ClientInternalLogic']]]
];

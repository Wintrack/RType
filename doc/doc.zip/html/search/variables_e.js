var searchData=
[
  ['port_0',['Port',['../structs___client.html#a4e271f770d6ed379717007b803727b31',1,'s_Client']]],
  ['pos_5fx_1',['pos_x',['../struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#acb19df082f4893c4505ca885396e9aae',1,'INSTRUCTION_Client_in_room']]],
  ['pos_5fy_2',['pos_y',['../struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#a57a73cc39b4763243eb3264fd790cfba',1,'INSTRUCTION_Client_in_room']]]
];

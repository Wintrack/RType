var searchData=
[
  ['send_5fbuffer_0',['send_buffer',['../class_client.html#a7a1f0ad887f25d25aa7658e132cab36f',1,'Client']]],
  ['sended_5finfo_1',['SENDED_INFO',['../class_lobby___client.html#ab4c0d2e4964f910914b5d25ed5ff3550',1,'Lobby_Client::SENDED_INFO()'],['../class_menu.html#afbbb679acd6d49fe3649fde444faa857',1,'Menu::SENDED_INFO()']]],
  ['sended_5finfos_2',['SENDED_INFOS',['../class_client_internal_logic.html#a145d6302ba64756399bfd71a6befa4f1',1,'ClientInternalLogic']]],
  ['sender_5fendpoint_3',['sender_endpoint',['../class_client.html#aee04c3f1f53d620e8ccd57335f804a8e',1,'Client']]],
  ['sender_5fendpoint_5f_4',['sender_endpoint_',['../class_server.html#a6f804ef8e965ff472b920ce6fbf1fdcf',1,'Server']]],
  ['socket_5f_5',['socket_',['../class_server.html#ab710f68f348bddbde185aa3828f77524',1,'Server']]],
  ['sourcerecexit_6',['sourceRecExit',['../class_lobby___client.html#a46a77105cf3c945ad6fb7129db4a3dfd',1,'Lobby_Client::sourceRecExit()'],['../class_menu.html#a771c55e62a343edf03c9a968213b8e0a',1,'Menu::sourceRecExit()']]],
  ['sourcerecnewgame_7',['sourceRecNewgame',['../class_lobby___client.html#a26e5acfd0f8c6157abac46c8fd7a47d3',1,'Lobby_Client::sourceRecNewgame()'],['../class_menu.html#a6573858dd58f2d2bfa0c7f5d62c4996b',1,'Menu::sourceRecNewgame()']]],
  ['sourcerecoption_8',['sourceRecOption',['../class_menu.html#a30a1f3357fa579f0d0bf0dabd2365526',1,'Menu']]],
  ['sz_9',['sz',['../struct_str__t.html#ab94674acae4352eea6a92d6416dba8a6',1,'Str_t']]]
];

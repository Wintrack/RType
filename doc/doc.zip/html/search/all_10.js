var searchData=
[
  ['verify_5fcache_0',['Verify_Cache',['../class_client_internal_logic.html#a67d8028cf60c1e84b05ee776b6018868',1,'ClientInternalLogic']]],
  ['verify_5fid_1',['Verify_ID',['../class_server_internal_logic.html#afa3c6e21516e394415148905da1847af',1,'ServerInternalLogic']]]
];

var searchData=
[
  ['s_5fclient_0',['s_Client',['../structs___client.html',1,'']]],
  ['ser_1',['ser',['../classser.html',1,'']]],
  ['server_2',['Server',['../class_server.html',1,'']]],
  ['serverinternallogic_3',['ServerInternalLogic',['../class_server_internal_logic.html',1,'']]]
];

var searchData=
[
  ['background_0',['BACKGROUND',['../_macro_8hpp.html#a850b2f07a67b73890889e63fb8a49fda',1,'Macro.hpp']]],
  ['baddude_1',['BADDUDE',['../_macro_8hpp.html#ab924da3a1c56935dfc1d44db05274d5e',1,'Macro.hpp']]],
  ['bullet_2',['BULLET',['../_macro_8hpp.html#a9c3c35f9545d4bd20d9c19ee86a3f067',1,'Macro.hpp']]]
];

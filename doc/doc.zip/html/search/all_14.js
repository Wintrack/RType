var searchData=
[
  ['var_5fdelimiter_0',['VAR_DELIMITER',['../_macro_8hpp.html#a16b4df4c531edc0aeb75f7776ccc2e18',1,'Macro.hpp']]],
  ['verify_5fcache_1',['Verify_Cache',['../class_client_internal_logic.html#a67d8028cf60c1e84b05ee776b6018868',1,'ClientInternalLogic']]],
  ['verify_5fid_2',['Verify_ID',['../class_server_internal_logic.html#afa3c6e21516e394415148905da1847af',1,'ServerInternalLogic']]]
];

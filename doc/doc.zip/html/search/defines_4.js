var searchData=
[
  ['return_5fins_0',['RETURN_INS',['../_macro_8hpp.html#a32893457ee15d019e17bbe0123e890ca',1,'Macro.hpp']]]
];

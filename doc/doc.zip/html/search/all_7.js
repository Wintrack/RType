var searchData=
[
  ['instruction_5fclient_5fin_5froom_0',['INSTRUCTION_Client_in_room',['../struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html',1,'']]],
  ['instruction_5fcreate_5froom_5fclient_1',['INSTRUCTION_CREATE_ROOM_Client',['../struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html',1,'']]],
  ['instruction_5fgeneric_2',['INSTRUCTION_GENERIC',['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html',1,'']]],
  ['instruction_5fjoin_5flobby_5fserv_3',['INSTRUCTION_JOIN_LOBBY_Serv',['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html',1,'']]],
  ['instruction_5fjoin_5froom_5fclient_4',['INSTRUCTION_JOIN_ROOM_Client',['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html',1,'']]],
  ['instruction_5fserv_5fto_5fclient_5froom_5',['INSTRUCTION_Serv_to_Client_room',['../struct_i_n_s_t_r_u_c_t_i_o_n___serv__to___client__room.html',1,'']]]
];

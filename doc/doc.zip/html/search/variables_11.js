var searchData=
[
  ['texture_0',['texture',['../classfire.html#a43fa496fe32c80dbec7f1de31793a36c',1,'fire::texture()'],['../struct_entity__to__display.html#aeaa55f9e4826b104fdb70e382f479ac6',1,'Entity_to_display::texture()']]],
  ['type_1',['type',['../struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#a4c791f1068e025edbd9534246a379ae2',1,'INSTRUCTION_Client_in_room']]]
];

var searchData=
[
  ['join_5flooby_0',['join_looby',['../class_lobby___client.html#a4a5437c7f79bca9c51b1374570b33940',1,'Lobby_Client::join_looby()'],['../class_menu.html#acda89d39eafacf54c3f59e3c7d2e10ab',1,'Menu::join_looby()']]],
  ['join_5froom_1',['join_room',['../class_lobby___client.html#a62ea320aaa3beb268f0bbe3d26232cf7',1,'Lobby_Client::join_room()'],['../class_menu.html#aaf45606ebd1e2624fa96b438e911e489',1,'Menu::join_room()']]]
];

var searchData=
[
  ['end_5fdata_0',['END_DATA',['../_macro_8hpp.html#ab989978585b78e98ff314e8abb5f9bb0',1,'Macro.hpp']]],
  ['exit_5fclient_5fins_1',['EXIT_CLIENT_INS',['../_macro_8hpp.html#a9c6c2937382da85f6be8f4cc819f4bb7',1,'Macro.hpp']]]
];

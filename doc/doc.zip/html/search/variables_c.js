var searchData=
[
  ['name_0',['name',['../struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html#a7f174858ab06b47ad9db9584951afe54',1,'INSTRUCTION_JOIN_ROOM_Client']]],
  ['name_5froom_1',['name_room',['../struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html#acc42ee32fbdf8b94ae63812ac7387535',1,'INSTRUCTION_CREATE_ROOM_Client']]],
  ['name_5froom_5fcreated_2',['name_room_created',['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#a2e86670769993895825734374c15ce6e',1,'INSTRUCTION_GENERIC']]],
  ['name_5fselected_3',['name_selected',['../struct_i_n_s_t_r_u_c_t_i_o_n___g_e_n_e_r_i_c.html#ada77bd1e8d1d660cd231d1393c9be33f',1,'INSTRUCTION_GENERIC']]],
  ['nbr_5flobby_4',['nbr_lobby',['../class_lobby___client.html#af2696e06ba8e264d3f1543e6dfd66991',1,'Lobby_Client']]]
];

var searchData=
[
  ['add_5fclient_0',['Add_client',['../class_room__server.html#ab1e1f2fbfa296ad3ed7ece5ae653716f',1,'Room_server']]],
  ['add_5fnew_5fplayer_1',['Add_new_player',['../class_server_internal_logic.html#a7e7444e80a1f70b65d519e57a16a9740',1,'ServerInternalLogic']]],
  ['add_5fnew_5froom_2',['add_new_room',['../class_lobby___serv.html#a7d23a1fa321ba0bb5f1477a9c166cf0d',1,'Lobby_Serv']]],
  ['asynchronic_5fcalculation_3',['Asynchronic_Calculation',['../class_server_internal_logic.html#a4e805d50e1bbf9242fc4ef1cf9299049',1,'ServerInternalLogic']]]
];

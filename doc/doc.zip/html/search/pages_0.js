var searchData=
[
  ['r_2dtype_0',['R-Type',['../index.html',1,'']]]
];

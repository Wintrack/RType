var class_server =
[
    [ "Server", "class_server.html#a370f6de26f1e0f7ac542ee575d7560a0", null ],
    [ "~Server", "class_server.html#a4b3aa2579cb1c8cd1d069582c14d0fa6", null ],
    [ "do_receive", "class_server.html#a9b3c864bf08fa970dd6d765266a1eb1c", null ],
    [ "do_send_specific", "class_server.html#a5e42bc74289932fc7b2b2228a4fd3b89", null ],
    [ "get_endpoint", "class_server.html#a5390eb0c3cf74e783533cdd3ae14e3f3", null ]
];
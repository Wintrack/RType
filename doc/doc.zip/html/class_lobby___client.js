var class_lobby___client =
[
    [ "Lobby_Client", "class_lobby___client.html#aa8ea0eedc553b499a86a22dcdc2808d3", null ],
    [ "~Lobby_Client", "class_lobby___client.html#a342835ee9c8f5cb4ceaa439618d172fa", null ],
    [ "Display", "class_lobby___client.html#a972cd577574db3289b6e874ea79fcb85", null ],
    [ "Lobby_page", "class_lobby___client.html#a21508987003aa11f2022a5710450a3fc", null ]
];
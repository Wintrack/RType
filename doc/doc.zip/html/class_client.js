var class_client =
[
    [ "Client", "class_client.html#a52fdee08bbb26ac9df241453bf86b6c8", null ],
    [ "~Client", "class_client.html#a840e519ca781888cbd54181572ebe3a7", null ],
    [ "Client_in_action", "class_client.html#a5a07615e690214e63dbb5ca6244ad1f5", null ],
    [ "Client_send", "class_client.html#a1d2c29be072bc0fcfab939e2d824cb58", null ],
    [ "do_receive", "class_client.html#af0ac45090920145015717a91111303fc", null ]
];
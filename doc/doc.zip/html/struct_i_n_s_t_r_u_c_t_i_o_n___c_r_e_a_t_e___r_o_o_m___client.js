var struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client =
[
    [ "instruction", "struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html#af34e093ea3d85779a19054c45d5828e9", null ],
    [ "maxplay", "struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html#a6bd8b4c1fdb3d79daf8fecc4f9189333", null ],
    [ "name_room", "struct_i_n_s_t_r_u_c_t_i_o_n___c_r_e_a_t_e___r_o_o_m___client.html#acc42ee32fbdf8b94ae63812ac7387535", null ]
];
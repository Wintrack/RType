var class_game =
[
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "~Game", "class_game.html#ae3d112ca6e0e55150d2fdbc704474530", null ],
    [ "gameLoop", "class_game.html#abb97042823a16f7004fd3c7a8138b9f6", null ],
    [ "getInput", "class_game.html#aaf9ea06829b84d18a1503fd930fead92", null ]
];
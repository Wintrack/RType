var structs___client =
[
    [ "IP", "structs___client.html#acaceb5c02181796f8119f32ace8af514", null ],
    [ "Port", "structs___client.html#a4e271f770d6ed379717007b803727b31", null ]
];
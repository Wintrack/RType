var struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client =
[
    [ "client", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html#a0e7cb7ced02cf0b127896df1e76161c6", null ],
    [ "instruction", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html#af7761952e4f132e7fa1e7b4af21e5771", null ],
    [ "name", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___r_o_o_m___client.html#a7f174858ab06b47ad9db9584951afe54", null ]
];
var class_server_internal_logic =
[
    [ "ServerInternalLogic", "class_server_internal_logic.html#a865abc15154eac68851bcbbe835ed439", null ],
    [ "~ServerInternalLogic", "class_server_internal_logic.html#a25213f3486186781dab3f657f934820b", null ],
    [ "Add_new_player", "class_server_internal_logic.html#a7e7444e80a1f70b65d519e57a16a9740", null ],
    [ "Asynchronic_Calculation", "class_server_internal_logic.html#a4e805d50e1bbf9242fc4ef1cf9299049", null ],
    [ "Create_entity", "class_server_internal_logic.html#a803be10d5b5ec882484f46f44ab5d055", null ],
    [ "DATABASE_Update", "class_server_internal_logic.html#a82534853923c5ca7601e8edab5d2a087", null ],
    [ "Receive_from_client", "class_server_internal_logic.html#ac818fb618348e26b07abcfe756353198", null ],
    [ "Verify_ID", "class_server_internal_logic.html#afa3c6e21516e394415148905da1847af", null ]
];
var default__doxy_8cpp =
[
    [ "Str_t", "struct_str__t.html", "struct_str__t" ],
    [ "Str_err_e", "default__doxy_8cpp.html#a453c49b2528434b9260435d9098c6114", [
      [ "STR_NO_ERR", "default__doxy_8cpp.html#a453c49b2528434b9260435d9098c6114a873f21f523dfc0783f52471131632a80", null ],
      [ "STR_EMPTY_ERR", "default__doxy_8cpp.html#a453c49b2528434b9260435d9098c6114a6553fe66986ddca61eecc927064bdc15", null ],
      [ "NB_STR_ERR", "default__doxy_8cpp.html#a453c49b2528434b9260435d9098c6114a8aff2f6d0b0a343fc66bbb89d2128ad9", null ]
    ] ],
    [ "main", "default__doxy_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe", null ]
];
var namespaces_dup =
[
    [ "Systems", "namespace_systems.html", "namespace_systems" ]
];
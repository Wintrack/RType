var struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room =
[
    [ "id", "struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#aa667c68974ce686250e508d330f39844", null ],
    [ "pos_x", "struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#acb19df082f4893c4505ca885396e9aae", null ],
    [ "pos_y", "struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#a57a73cc39b4763243eb3264fd790cfba", null ],
    [ "type", "struct_i_n_s_t_r_u_c_t_i_o_n___client__in__room.html#a4c791f1068e025edbd9534246a379ae2", null ]
];
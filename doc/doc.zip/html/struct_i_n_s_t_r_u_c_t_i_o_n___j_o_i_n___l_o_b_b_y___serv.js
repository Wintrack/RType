var struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv =
[
    [ "instruction", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html#a4a2f76ccdb75f6f55545063e6b39b433", null ],
    [ "maxpl", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html#aaccc2590738cc2e59411065062211e03", null ],
    [ "rooms_in_lobby", "struct_i_n_s_t_r_u_c_t_i_o_n___j_o_i_n___l_o_b_b_y___serv.html#af3ad6ac50f2cf3f0c9917903f06daa34", null ]
];
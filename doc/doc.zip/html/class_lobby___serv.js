var class_lobby___serv =
[
    [ "Lobby_Serv", "class_lobby___serv.html#a98cb74a11ef2846f2f641f48b7ae4cd6", null ],
    [ "~Lobby_Serv", "class_lobby___serv.html#a8d36bbf09970738f5c3106d66d5a408e", null ],
    [ "add_new_room", "class_lobby___serv.html#a7d23a1fa321ba0bb5f1477a9c166cf0d", null ],
    [ "destroy_room", "class_lobby___serv.html#a08ec5453f200ba03ee6bd1ea0e6ee4e3", null ],
    [ "join_room", "class_lobby___serv.html#abcd3321e3534bd52c7061db3a8a94e98", null ]
];
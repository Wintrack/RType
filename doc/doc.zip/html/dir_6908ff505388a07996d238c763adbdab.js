var dir_6908ff505388a07996d238c763adbdab =
[
    [ "ClientInternalLogic.cpp", "_client_internal_logic_8cpp.html", null ],
    [ "main.cpp", "client_2main_8cpp.html", null ]
];
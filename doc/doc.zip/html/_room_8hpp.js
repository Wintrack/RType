var _room_8hpp =
[
    [ "Room_server", "class_room__server.html", "class_room__server" ],
    [ "Room_client", "class_room__client.html", null ]
];
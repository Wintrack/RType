var classplayer_1_1_c_player =
[
    [ "CPlayer", "classplayer_1_1_c_player.html#a91ed2a2a0c4f4aa1ba480b74ed353b51", null ],
    [ "~CPlayer", "classplayer_1_1_c_player.html#a0a50d2f32e2e135ebf26076986bddfb1", null ],
    [ "add", "classplayer_1_1_c_player.html#a8be0b27d0749fa87f7b574ace798b135", null ],
    [ "next", "classplayer_1_1_c_player.html#a7be95660e801b8dfe22e01451e859fce", null ],
    [ "play", "classplayer_1_1_c_player.html#af72054307e459546e3898137d165ebeb", null ],
    [ "previous", "classplayer_1_1_c_player.html#a6421f061cfe7b72665d15a453555887e", null ],
    [ "stop", "classplayer_1_1_c_player.html#ad943ab1e4761fd215c0b51646a02c79a", null ]
];
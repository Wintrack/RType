var struct_entity__to__display =
[
    [ "id", "struct_entity__to__display.html#a16111787afac59ff6aec9c5972638a46", null ],
    [ "texture", "struct_entity__to__display.html#aeaa55f9e4826b104fdb70e382f479ac6", null ]
];